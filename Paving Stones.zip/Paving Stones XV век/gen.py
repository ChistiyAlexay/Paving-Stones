import bpy

def my_generator_node_group():
    if "My Generator" not in bpy.data.node_groups:
        my_generator = bpy.data.node_groups.new(type='GeometryNodeTree', name="My Generator")


    

        #initialize my_generator nodes
        #node Math
        math = my_generator.nodes.new("ShaderNodeMath")
        math.name = "Math"
        math.operation = 'MULTIPLY'
        math.use_clamp = False

        #node Math.002
        math_002 = my_generator.nodes.new("ShaderNodeMath")
        math_002.name = "Math.002"
        math_002.operation = 'MULTIPLY'
        math_002.use_clamp = False
        #Value_001
        math_002.inputs[1].default_value = 2.0

        #node Math.003
        math_003 = my_generator.nodes.new("ShaderNodeMath")
        math_003.name = "Math.003"
        math_003.operation = 'MULTIPLY'
        math_003.use_clamp = False

        #node Math.004
        math_004 = my_generator.nodes.new("ShaderNodeMath")
        math_004.name = "Math.004"
        math_004.operation = 'SUBTRACT'
        math_004.use_clamp = False
        #Value_001
        math_004.inputs[1].default_value = 1.0

        #node Group Input
        group_input = my_generator.nodes.new("NodeGroupInput")
        group_input.name = "Group Input"
        #my_generator inputs
        #input Geometry
        my_generator.inputs.new('NodeSocketGeometry', "Geometry")
        my_generator.inputs[0].attribute_domain = 'POINT'

        #input Block Width
        my_generator.inputs.new('NodeSocketFloat', "Block Width")
        my_generator.inputs[1].default_value = 0.26
        my_generator.inputs[1].min_value = -3.4028234663852886e+38
        my_generator.inputs[1].max_value = 3.4028234663852886e+38
        my_generator.inputs[1].attribute_domain = 'POINT'

        #input Block Count
        my_generator.inputs.new('NodeSocketInt', "Block Count")
        my_generator.inputs[2].default_value = 11
        my_generator.inputs[2].min_value = -2147483648
        my_generator.inputs[2].max_value = 2147483647
        my_generator.inputs[2].attribute_domain = 'POINT'

        #input Level detalise
        my_generator.inputs.new('NodeSocketInt', "Level detalise")
        my_generator.inputs[3].default_value = 2
        my_generator.inputs[3].min_value = 0
        my_generator.inputs[3].max_value = 3
        my_generator.inputs[3].attribute_domain = 'POINT'

        #input Rows
        my_generator.inputs.new('NodeSocketInt', "Rows")
        my_generator.inputs[4].default_value = 1
        my_generator.inputs[4].min_value = -2147483648
        my_generator.inputs[4].max_value = 2147483647
        my_generator.inputs[4].attribute_domain = 'POINT'

        #input Block Scale
        my_generator.inputs.new('NodeSocketFloat', "Block Scale")
        my_generator.inputs[5].default_value = 0.96
        my_generator.inputs[5].min_value = 0.0
        my_generator.inputs[5].max_value = 1.0
        my_generator.inputs[5].attribute_domain = 'POINT'

        #input Extrude
        my_generator.inputs.new('NodeSocketFloat', "Extrude")
        my_generator.inputs[6].default_value = 0
        my_generator.inputs[6].min_value = -10000.0
        my_generator.inputs[6].max_value = 10000.0
        my_generator.inputs[6].attribute_domain = 'POINT'

        #input Rougress
        my_generator.inputs.new('NodeSocketFloat', "Rougress")
        my_generator.inputs[7].default_value = 0
        my_generator.inputs[7].min_value = -10000.0
        my_generator.inputs[7].max_value = 10000.0
        my_generator.inputs[7].attribute_domain = 'POINT'

        #input Height
        my_generator.inputs.new('NodeSocketFloat', "Height")
        my_generator.inputs[8].default_value = 1.0
        my_generator.inputs[8].min_value = -3.4028234663852886e+38
        my_generator.inputs[8].max_value = 3.4028234663852886e+38
        my_generator.inputs[8].attribute_domain = 'POINT'


        group_input.outputs[7].hide = True
        group_input.outputs[8].hide = True

        #node Combine XYZ
        combine_xyz = my_generator.nodes.new("ShaderNodeCombineXYZ")
        combine_xyz.name = "Combine XYZ"
        #X
        combine_xyz.inputs[0].default_value = 0.0
        #Z
        combine_xyz.inputs[2].default_value = 0.0

        #node Curve Line
        curve_line = my_generator.nodes.new("GeometryNodeCurvePrimitiveLine")
        curve_line.name = "Curve Line"
        curve_line.mode = 'POINTS'
        #Start
        curve_line.inputs[0].default_value = (0.0, 0.0, 0.0)

        #node Curve Circle
        curve_circle = my_generator.nodes.new("GeometryNodeCurvePrimitiveCircle")
        curve_circle.name = "Curve Circle"
        curve_circle.mode = 'RADIUS'
        #Resolution
        curve_circle.inputs[0].default_value = 6

        #node Resample Curve
        resample_curve = my_generator.nodes.new("GeometryNodeResampleCurve")
        resample_curve.name = "Resample Curve"
        resample_curve.mode = 'COUNT'
        #Selection
        resample_curve.inputs[1].default_value = True

        #node Instance on Points
        instance_on_points = my_generator.nodes.new("GeometryNodeInstanceOnPoints")
        instance_on_points.name = "Instance on Points"
        #Selection
        instance_on_points.inputs[1].default_value = True
        #Pick Instance
        instance_on_points.inputs[3].default_value = False
        #Instance Index
        instance_on_points.inputs[4].default_value = 0
        #Rotation
        instance_on_points.inputs[5].default_value = (0.0, 0.0, 0.0)
        #Scale
        instance_on_points.inputs[6].default_value = (1.0, 1.0, 1.0)

        #node Reroute
        reroute = my_generator.nodes.new("NodeReroute")
        reroute.name = "Reroute"
        #node Math.008
        math_008 = my_generator.nodes.new("ShaderNodeMath")
        math_008.name = "Math.008"
        math_008.operation = 'COSINE'
        math_008.use_clamp = False
        #Value
        math_008.inputs[0].default_value = 0.5239999890327454

        #node Math.001
        math_001 = my_generator.nodes.new("ShaderNodeMath")
        math_001.name = "Math.001"
        math_001.operation = 'COSINE'
        math_001.use_clamp = False
        #Value
        math_001.inputs[0].default_value = 0.5239999890327454

        #node Group Input.001
        group_input_001 = my_generator.nodes.new("NodeGroupInput")
        group_input_001.name = "Group Input.001"
        group_input_001.outputs[7].hide = True
        group_input_001.outputs[8].hide = True

        #node Math.007
        math_007 = my_generator.nodes.new("ShaderNodeMath")
        math_007.name = "Math.007"
        math_007.operation = 'MULTIPLY'
        math_007.use_clamp = False

        #node Duplicate Elements
        duplicate_elements = my_generator.nodes.new("GeometryNodeDuplicateElements")
        duplicate_elements.name = "Duplicate Elements"
        duplicate_elements.domain = 'INSTANCE'
        #Selection
        duplicate_elements.inputs[1].default_value = True

        #node Math.010
        math_010 = my_generator.nodes.new("ShaderNodeMath")
        math_010.name = "Math.010"
        math_010.operation = 'MULTIPLY'
        math_010.use_clamp = False

        #node Reroute.001
        reroute_001 = my_generator.nodes.new("NodeReroute")
        reroute_001.name = "Reroute.001"
        #node Reroute.003
        reroute_003 = my_generator.nodes.new("NodeReroute")
        reroute_003.name = "Reroute.003"
        #node Reroute.002
        reroute_002 = my_generator.nodes.new("NodeReroute")
        reroute_002.name = "Reroute.002"
        #node Combine XYZ.001
        combine_xyz_001 = my_generator.nodes.new("ShaderNodeCombineXYZ")
        combine_xyz_001.name = "Combine XYZ.001"
        #Z
        combine_xyz_001.inputs[2].default_value = 0.0

        #node Math.009
        math_009 = my_generator.nodes.new("ShaderNodeMath")
        math_009.name = "Math.009"
        math_009.operation = 'MULTIPLY'
        math_009.use_clamp = False
        #Value_001
        math_009.inputs[1].default_value = 1.5

        #node Math.011
        math_011 = my_generator.nodes.new("ShaderNodeMath")
        math_011.name = "Math.011"
        math_011.operation = 'MULTIPLY'
        math_011.use_clamp = False

        #node Math.005
        math_005 = my_generator.nodes.new("ShaderNodeMath")
        math_005.name = "Math.005"
        math_005.operation = 'MODULO'
        math_005.use_clamp = False
        #Value_001
        math_005.inputs[1].default_value = 2.0

        #node Realize Instances
        realize_instances = my_generator.nodes.new("GeometryNodeRealizeInstances")
        realize_instances.name = "Realize Instances"
        realize_instances.legacy_behavior = False

        #node Vector Math
        vector_math = my_generator.nodes.new("ShaderNodeVectorMath")
        vector_math.name = "Vector Math"
        vector_math.operation = 'SUBTRACT'

        #node Vector Math.001
        vector_math_001 = my_generator.nodes.new("ShaderNodeVectorMath")
        vector_math_001.name = "Vector Math.001"
        vector_math_001.operation = 'MULTIPLY'
        #Vector_001
        vector_math_001.inputs[1].default_value = (0.5, 0.0, 0.0)

        #node Bounding Box
        bounding_box = my_generator.nodes.new("GeometryNodeBoundBox")
        bounding_box.name = "Bounding Box"

        #node Vector Math.002
        vector_math_002 = my_generator.nodes.new("ShaderNodeVectorMath")
        vector_math_002.name = "Vector Math.002"
        vector_math_002.operation = 'ADD'

        #node Reroute.004
        reroute_004 = my_generator.nodes.new("NodeReroute")
        reroute_004.name = "Reroute.004"
        #node Vector Math.003
        vector_math_003 = my_generator.nodes.new("ShaderNodeVectorMath")
        vector_math_003.name = "Vector Math.003"
        vector_math_003.operation = 'SCALE'
        #Scale
        vector_math_003.inputs[3].default_value = -1.0

        #node Set Position.001
        set_position_001 = my_generator.nodes.new("GeometryNodeSetPosition")
        set_position_001.name = "Set Position.001"
        #Selection
        set_position_001.inputs[1].default_value = True
        #Position
        set_position_001.inputs[2].default_value = (0.0, 0.0, 0.0)

        #node Reroute.005
        reroute_005 = my_generator.nodes.new("NodeReroute")
        reroute_005.name = "Reroute.005"
        #node Set Position
        set_position = my_generator.nodes.new("GeometryNodeSetPosition")
        set_position.name = "Set Position"
        #Selection
        set_position.inputs[1].default_value = True
        #Position
        set_position.inputs[2].default_value = (0.0, 0.0, 0.0)

        #node Reroute.006
        reroute_006 = my_generator.nodes.new("NodeReroute")
        reroute_006.name = "Reroute.006"
        #node Fill Curve
        fill_curve = my_generator.nodes.new("GeometryNodeFillCurve")
        fill_curve.name = "Fill Curve"
        fill_curve.mode = 'NGONS'

        #node Scale Instances
        scale_instances = my_generator.nodes.new("GeometryNodeScaleInstances")
        scale_instances.name = "Scale Instances"
        #Selection
        scale_instances.inputs[1].default_value = True
        #Center
        scale_instances.inputs[3].default_value = (0.0, 0.0, 0.0)
        #Local Space
        scale_instances.inputs[4].default_value = True

        #node Group Input.002
        group_input_002 = my_generator.nodes.new("NodeGroupInput")
        group_input_002.name = "Group Input.002"
        group_input_002.outputs[7].hide = True
        group_input_002.outputs[8].hide = True

        #node Separate XYZ
        separate_xyz = my_generator.nodes.new("ShaderNodeSeparateXYZ")
        separate_xyz.name = "Separate XYZ"

        #node Realize Instances.001
        realize_instances_001 = my_generator.nodes.new("GeometryNodeRealizeInstances")
        realize_instances_001.name = "Realize Instances.001"
        realize_instances_001.legacy_behavior = False

        #node Bounding Box.001
        bounding_box_001 = my_generator.nodes.new("GeometryNodeBoundBox")
        bounding_box_001.name = "Bounding Box.001"

        #node Position
        position = my_generator.nodes.new("GeometryNodeInputPosition")
        position.name = "Position"

        #node Math.012
        math_012 = my_generator.nodes.new("ShaderNodeMath")
        math_012.name = "Math.012"
        math_012.operation = 'SINE'
        math_012.use_clamp = False
        #Value
        math_012.inputs[0].default_value = 0.5239999890327454

        #node Math.013
        math_013 = my_generator.nodes.new("ShaderNodeMath")
        math_013.name = "Math.013"
        math_013.operation = 'COSINE'
        math_013.use_clamp = False
        #Value
        math_013.inputs[0].default_value = 0.5239999890327454

        #node Math.015
        math_015 = my_generator.nodes.new("ShaderNodeMath")
        math_015.name = "Math.015"
        math_015.operation = 'ADD'
        math_015.use_clamp = False

        #node Separate XYZ.001
        separate_xyz_001 = my_generator.nodes.new("ShaderNodeSeparateXYZ")
        separate_xyz_001.name = "Separate XYZ.001"

        #node Math.006
        math_006 = my_generator.nodes.new("ShaderNodeMath")
        math_006.name = "Math.006"
        math_006.operation = 'MULTIPLY'
        math_006.use_clamp = False

        #node Math.018
        math_018 = my_generator.nodes.new("ShaderNodeMath")
        math_018.name = "Math.018"
        math_018.operation = 'SUBTRACT'
        math_018.use_clamp = False

        #node Math.017
        math_017 = my_generator.nodes.new("ShaderNodeMath")
        math_017.name = "Math.017"
        math_017.operation = 'SUBTRACT'
        math_017.use_clamp = False

        #node Math.014
        math_014 = my_generator.nodes.new("ShaderNodeMath")
        math_014.name = "Math.014"
        math_014.operation = 'MULTIPLY'
        math_014.use_clamp = False

        #node Math.020
        math_020 = my_generator.nodes.new("ShaderNodeMath")
        math_020.name = "Math.020"
        math_020.operation = 'MINIMUM'
        math_020.use_clamp = False

        #node Separate XYZ.002
        separate_xyz_002 = my_generator.nodes.new("ShaderNodeSeparateXYZ")
        separate_xyz_002.name = "Separate XYZ.002"

        #node Math.019
        math_019 = my_generator.nodes.new("ShaderNodeMath")
        math_019.name = "Math.019"
        math_019.operation = 'MINIMUM'
        math_019.use_clamp = False

        #node Math.022
        math_022 = my_generator.nodes.new("ShaderNodeMath")
        math_022.name = "Math.022"
        math_022.operation = 'MAXIMUM'
        math_022.use_clamp = False

        #node Math.016
        math_016 = my_generator.nodes.new("ShaderNodeMath")
        math_016.name = "Math.016"
        math_016.operation = 'ADD'
        math_016.use_clamp = False

        #node Math.021
        math_021 = my_generator.nodes.new("ShaderNodeMath")
        math_021.name = "Math.021"
        math_021.operation = 'MAXIMUM'
        math_021.use_clamp = False

        #node Combine XYZ.002
        combine_xyz_002 = my_generator.nodes.new("ShaderNodeCombineXYZ")
        combine_xyz_002.name = "Combine XYZ.002"
        #Z
        combine_xyz_002.inputs[2].default_value = 0.0

        #node Reroute.007
        reroute_007 = my_generator.nodes.new("NodeReroute")
        reroute_007.name = "Reroute.007"
        #node Set Position.002
        set_position_002 = my_generator.nodes.new("GeometryNodeSetPosition")
        set_position_002.name = "Set Position.002"
        #Selection
        set_position_002.inputs[1].default_value = True
        #Offset
        set_position_002.inputs[3].default_value = (0.0, 0.0, 0.0)

        #node Vector Math.004
        vector_math_004 = my_generator.nodes.new("ShaderNodeVectorMath")
        vector_math_004.name = "Vector Math.004"
        vector_math_004.operation = 'MULTIPLY'
        #Vector
        vector_math_004.inputs[0].default_value = (0.0, 0.0, 0.30000001192092896)

        #node Random Value
        random_value = my_generator.nodes.new("FunctionNodeRandomValue")
        random_value.name = "Random Value"
        random_value.data_type = 'FLOAT_VECTOR'
        #Max
        random_value.inputs[1].default_value = (1.0, 1.0, 1.0)
        #ID
        random_value.inputs[7].default_value = 0
        #Seed
        random_value.inputs[8].default_value = 0

        #node Math.023
        math_023 = my_generator.nodes.new("ShaderNodeMath")
        math_023.name = "Math.023"
        math_023.operation = 'SUBTRACT'
        math_023.use_clamp = False
        #Value
        math_023.inputs[0].default_value = 1.0

        #node Extrude Mesh
        extrude_mesh = my_generator.nodes.new("GeometryNodeExtrudeMesh")
        extrude_mesh.name = "Extrude Mesh"
        extrude_mesh.mode = 'FACES'
        #Selection
        extrude_mesh.inputs[1].default_value = True
        #Individual
        extrude_mesh.inputs[4].default_value = True

        #node Group Input.005
        group_input_005 = my_generator.nodes.new("NodeGroupInput")
        group_input_005.name = "Group Input.005"
        group_input_005.outputs[7].hide = True
        group_input_005.outputs[8].hide = True

        #node Group Input.004
        group_input_004 = my_generator.nodes.new("NodeGroupInput")
        group_input_004.name = "Group Input.004"
        group_input_004.outputs[7].hide = True
        group_input_004.outputs[8].hide = True

        #node Reroute.008
        reroute_008 = my_generator.nodes.new("NodeReroute")
        reroute_008.name = "Reroute.008"
        #node Reroute.009
        reroute_009 = my_generator.nodes.new("NodeReroute")
        reroute_009.name = "Reroute.009"
        #node Position.001
        position_001 = my_generator.nodes.new("GeometryNodeInputPosition")
        position_001.name = "Position.001"

        #node Bounding Box.002
        bounding_box_002 = my_generator.nodes.new("GeometryNodeBoundBox")
        bounding_box_002.name = "Bounding Box.002"

        #node Vector Math.005
        vector_math_005 = my_generator.nodes.new("ShaderNodeVectorMath")
        vector_math_005.name = "Vector Math.005"
        vector_math_005.operation = 'SUBTRACT'

        #node Math.024
        math_024 = my_generator.nodes.new("ShaderNodeMath")
        math_024.name = "Math.024"
        math_024.operation = 'SUBTRACT'
        math_024.use_clamp = False

        #node Separate XYZ.003
        separate_xyz_003 = my_generator.nodes.new("ShaderNodeSeparateXYZ")
        separate_xyz_003.name = "Separate XYZ.003"

        #node Separate XYZ.005
        separate_xyz_005 = my_generator.nodes.new("ShaderNodeSeparateXYZ")
        separate_xyz_005.name = "Separate XYZ.005"

        #node Math.025
        math_025 = my_generator.nodes.new("ShaderNodeMath")
        math_025.name = "Math.025"
        math_025.operation = 'DIVIDE'
        math_025.use_clamp = False

        #node Group Input.006
        group_input_006 = my_generator.nodes.new("NodeGroupInput")
        group_input_006.name = "Group Input.006"
        group_input_006.outputs[7].hide = True
        group_input_006.outputs[8].hide = True

        #node Math.027
        math_027 = my_generator.nodes.new("ShaderNodeMath")
        math_027.name = "Math.027"
        math_027.operation = 'SUBTRACT'
        math_027.use_clamp = False
        #Value
        math_027.inputs[0].default_value = 400.0
        #Value_001
        math_027.inputs[1].default_value = 1.0

        #node Position.002
        position_002 = my_generator.nodes.new("GeometryNodeInputPosition")
        position_002.name = "Position.002"

        #node Group Input.007
        group_input_007 = my_generator.nodes.new("NodeGroupInput")
        group_input_007.name = "Group Input.007"
        group_input_007.outputs[7].hide = True
        group_input_007.outputs[8].hide = True

        #node Math.026
        math_026 = my_generator.nodes.new("ShaderNodeMath")
        math_026.name = "Math.026"
        math_026.operation = 'MULTIPLY'
        math_026.use_clamp = False

        #node Normal
        normal = my_generator.nodes.new("GeometryNodeInputNormal")
        normal.name = "Normal"

        #node Vector Math.006
        vector_math_006 = my_generator.nodes.new("ShaderNodeVectorMath")
        vector_math_006.name = "Vector Math.006"
        vector_math_006.operation = 'MULTIPLY'

        #node Separate XYZ.004
        separate_xyz_004 = my_generator.nodes.new("ShaderNodeSeparateXYZ")
        separate_xyz_004.name = "Separate XYZ.004"

        #node Combine XYZ.003
        combine_xyz_003 = my_generator.nodes.new("ShaderNodeCombineXYZ")
        combine_xyz_003.name = "Combine XYZ.003"
        #X
        combine_xyz_003.inputs[0].default_value = 0.0
        #Y
        combine_xyz_003.inputs[1].default_value = 0.0

        #node Vector Math.007
        vector_math_007 = my_generator.nodes.new("ShaderNodeVectorMath")
        vector_math_007.name = "Vector Math.007"
        vector_math_007.operation = 'ADD'

        #node Vector Math.008
        vector_math_008 = my_generator.nodes.new("ShaderNodeVectorMath")
        vector_math_008.name = "Vector Math.008"
        vector_math_008.operation = 'ADD'

        #node Voronoi Texture
        voronoi_texture = my_generator.nodes.new("ShaderNodeTexVoronoi")
        voronoi_texture.name = "Voronoi Texture"
        voronoi_texture.distance = 'EUCLIDEAN'
        voronoi_texture.feature = 'SMOOTH_F1'
        voronoi_texture.voronoi_dimensions = '3D'
        #Vector
        voronoi_texture.inputs[0].default_value = (0.0, 0.0, 0.0)
        #Scale
        voronoi_texture.inputs[2].default_value = 1.149999976158142
        #Smoothness
        voronoi_texture.inputs[3].default_value = 1.0
        #Randomness
        voronoi_texture.inputs[5].default_value = 1.0

        #node Vector Math.009
        vector_math_009 = my_generator.nodes.new("ShaderNodeVectorMath")
        vector_math_009.name = "Vector Math.009"
        vector_math_009.operation = 'SUBTRACT'
        #Vector_001
        vector_math_009.inputs[1].default_value = (0.5, 0.5, 0.0)

        #node Group Input.008
        group_input_008 = my_generator.nodes.new("NodeGroupInput")
        group_input_008.name = "Group Input.008"
        group_input_008.outputs[0].hide = True
        group_input_008.outputs[1].hide = True
        group_input_008.outputs[2].hide = True
        group_input_008.outputs[3].hide = True
        group_input_008.outputs[4].hide = True
        group_input_008.outputs[5].hide = True
        group_input_008.outputs[6].hide = True
        group_input_008.outputs[8].hide = True
        group_input_008.outputs[9].hide = True

        #node Set Position.003
        set_position_003 = my_generator.nodes.new("GeometryNodeSetPosition")
        set_position_003.name = "Set Position.003"
        #Selection
        set_position_003.inputs[1].default_value = True
        #Offset
        set_position_003.inputs[3].default_value = (0.0, 0.0, 0.0)

        #node Vector Math.010
        vector_math_010 = my_generator.nodes.new("ShaderNodeVectorMath")
        vector_math_010.name = "Vector Math.010"
        vector_math_010.operation = 'SCALE'

        #node Subdivide Mesh
        subdivide_mesh = my_generator.nodes.new("GeometryNodeSubdivideMesh")
        subdivide_mesh.name = "Subdivide Mesh"

        #node Reroute.010
        reroute_010 = my_generator.nodes.new("NodeReroute")
        reroute_010.name = "Reroute.010"
        #node Set Position.004
        set_position_004 = my_generator.nodes.new("GeometryNodeSetPosition")
        set_position_004.name = "Set Position.004"
        #Position
        set_position_004.inputs[2].default_value = (0.0, 0.0, 0.0)

        #node Store Named Attribute
        store_named_attribute = my_generator.nodes.new("GeometryNodeStoreNamedAttribute")
        store_named_attribute.name = "Store Named Attribute"
        store_named_attribute.data_type = 'FLOAT'
        store_named_attribute.domain = 'POINT'
        #Selection
        store_named_attribute.inputs[1].default_value = True
        #Name
        store_named_attribute.inputs[2].default_value = "Bottom"

        #node Compare
        compare = my_generator.nodes.new("FunctionNodeCompare")
        compare.name = "Compare"
        compare.data_type = 'FLOAT'
        compare.mode = 'ELEMENT'
        compare.operation = 'EQUAL'
        #B
        compare.inputs[1].default_value = 0.0
        #Epsilon
        compare.inputs[12].default_value = 0.0010000000474974513

        #node Separate XYZ.006
        separate_xyz_006 = my_generator.nodes.new("ShaderNodeSeparateXYZ")
        separate_xyz_006.name = "Separate XYZ.006"

        #node Position.003
        position_003 = my_generator.nodes.new("GeometryNodeInputPosition")
        position_003.name = "Position.003"

        #node Boolean Math
        boolean_math = my_generator.nodes.new("FunctionNodeBooleanMath")
        boolean_math.name = "Boolean Math"
        boolean_math.operation = 'NOT'

        #node Named Attribute
        named_attribute = my_generator.nodes.new("GeometryNodeInputNamedAttribute")
        named_attribute.name = "Named Attribute"
        named_attribute.data_type = 'FLOAT'
        #Name
        named_attribute.inputs[0].default_value = "Bottom"

        #node Group Input.009
        group_input_009 = my_generator.nodes.new("NodeGroupInput")
        group_input_009.name = "Group Input.009"
        group_input_009.outputs[0].hide = True
        group_input_009.outputs[1].hide = True
        group_input_009.outputs[2].hide = True
        group_input_009.outputs[3].hide = True
        group_input_009.outputs[4].hide = True
        group_input_009.outputs[5].hide = True
        group_input_009.outputs[6].hide = True
        group_input_009.outputs[7].hide = True
        group_input_009.outputs[9].hide = True

        #node Group Output
        group_output = my_generator.nodes.new("NodeGroupOutput")
        group_output.name = "Group Output"
        group_output.is_active_output = True
        #my_generator outputs
        #output Geometry
        my_generator.outputs.new('NodeSocketGeometry', "Geometry")
        my_generator.outputs[0].attribute_domain = 'POINT'



        #node Sample Index
        sample_index = my_generator.nodes.new("GeometryNodeSampleIndex")
        sample_index.name = "Sample Index"
        sample_index.clamp = True
        sample_index.data_type = 'FLOAT_VECTOR'
        sample_index.domain = 'POINT'

        #node Sample Index.001
        sample_index_001 = my_generator.nodes.new("GeometryNodeSampleIndex")
        sample_index_001.name = "Sample Index.001"
        sample_index_001.clamp = True
        sample_index_001.data_type = 'FLOAT_VECTOR'
        sample_index_001.domain = 'POINT'

        #node Set Shade Smooth
        set_shade_smooth = my_generator.nodes.new("GeometryNodeSetShadeSmooth")
        set_shade_smooth.name = "Set Shade Smooth"
        #Selection
        set_shade_smooth.inputs[1].default_value = True
        #Shade Smooth
        set_shade_smooth.inputs[2].default_value = True

        #node Integer
        integer = my_generator.nodes.new("FunctionNodeInputInt")
        integer.name = "Integer"
        integer.integer = 0

        #node Resample Curve.001
        resample_curve_001 = my_generator.nodes.new("GeometryNodeResampleCurve")
        resample_curve_001.name = "Resample Curve.001"
        resample_curve_001.mode = 'COUNT'
        #Selection
        resample_curve_001.inputs[1].default_value = True
        #Count
        resample_curve_001.inputs[2].default_value = 400



        #Set locations
        math.location = (-78.38314056396484, 65.84874725341797)
        math_002.location = (91.98863983154297, 61.43559265136719)
        math_003.location = (278.3268127441406, 177.40402221679688)
        math_004.location = (64.85914611816406, 275.0155029296875)
        group_input.location = (-340.0, 0.0)
        combine_xyz.location = (470.3143005371094, 222.8618927001953)
        curve_line.location = (733.0025024414062, 174.96835327148438)
        curve_circle.location = (944.1880493164062, -73.80715942382812)
        resample_curve.location = (933.72705078125, 161.78831481933594)
        instance_on_points.location = (1165.21484375, 168.45974731445312)
        reroute.location = (1339.2958984375, -391.96795654296875)
        math_008.location = (1386.8720703125, -93.29722595214844)
        math_001.location = (-293.6210632324219, 161.56289672851562)
        group_input_001.location = (679.6866455078125, -285.7415771484375)
        math_007.location = (1571.959716796875, -99.1927490234375)
        duplicate_elements.location = (1380.2982177734375, 192.25411987304688)
        math_010.location = (1953.447021484375, -109.55085754394531)
        reroute_001.location = (1264.434326171875, -277.3967590332031)
        reroute_003.location = (1872.834716796875, -362.6563415527344)
        reroute_002.location = (1491.3074951171875, -351.1192932128906)
        combine_xyz_001.location = (2125.219970703125, 59.39015579223633)
        math_009.location = (1786.7763671875, -118.60881042480469)
        math_011.location = (1773.268310546875, 102.30290222167969)
        math_005.location = (1588.324951171875, 96.92001342773438)
        realize_instances.location = (2596.4150390625, 129.47677612304688)
        vector_math.location = (2974.861083984375, 134.319091796875)
        vector_math_001.location = (3186.452392578125, 133.10853576660156)
        bounding_box.location = (2768.106201171875, 105.26517486572266)
        vector_math_002.location = (3424.453125, 268.64398193359375)
        reroute_004.location = (2956.105224609375, 167.88648986816406)
        vector_math_003.location = (3623.9130859375, 252.03366088867188)
        set_position_001.location = (3797.76123046875, 249.4162139892578)
        reroute_005.location = (3762.254150390625, 326.59893798828125)
        set_position.location = (2386.219482421875, 165.92259216308594)
        reroute_006.location = (2635.644775390625, 301.73284912109375)
        fill_curve.location = (4007.48876953125, 262.442626953125)
        scale_instances.location = (4279.3720703125, 270.2950439453125)
        group_input_002.location = (4056.21923828125, 98.77413177490234)
        separate_xyz.location = (5105.4716796875, 239.21261596679688)
        realize_instances_001.location = (4600.115234375, 288.97589111328125)
        bounding_box_001.location = (4838.814453125, 253.60885620117188)
        position.location = (4887.04296875, -119.38512420654297)
        math_012.location = (4875.37841796875, -222.0732421875)
        math_013.location = (4865.7783203125, -404.7955322265625)
        math_015.location = (5358.978515625, 256.19659423828125)
        separate_xyz_001.location = (5100.0, 100.0)
        math_006.location = (5116.02880859375, -216.83827209472656)
        math_018.location = (5364.572265625, -290.6988220214844)
        math_017.location = (5358.7998046875, 82.35604858398438)
        math_014.location = (5106.4287109375, -399.560546875)
        math_020.location = (5603.89453125, -155.37110900878906)
        separate_xyz_002.location = (5107.36474609375, -51.09263610839844)
        math_019.location = (5603.1533203125, 49.78886032104492)
        math_022.location = (5824.1103515625, -124.3675537109375)
        math_016.location = (5367.35595703125, -102.3924789428711)
        math_021.location = (5833.88330078125, 55.87757873535156)
        combine_xyz_002.location = (6042.140625, 1.4085578918457031)
        reroute_007.location = (5000.568359375, 386.9888000488281)
        set_position_002.location = (6261.6376953125, 121.59866333007812)
        vector_math_004.location = (6742.23876953125, -26.173023223876953)
        random_value.location = (6534.54443359375, -177.74002075195312)
        math_023.location = (6309.796875, -167.22377014160156)
        extrude_mesh.location = (6963.22509765625, 150.39369201660156)
        group_input_005.location = (7134.033203125, -2.9405059814453125)
        group_input_004.location = (6098.314453125, -264.1686096191406)
        reroute_008.location = (8892.9892578125, -442.8719482421875)
        reroute_009.location = (9976.4462890625, -455.8187561035156)
        position_001.location = (8744.166015625, 27.457229614257812)
        bounding_box_002.location = (8738.0869140625, 160.14456176757812)
        vector_math_005.location = (8947.787109375, -33.14434814453125)
        math_024.location = (9168.0703125, 212.9584503173828)
        separate_xyz_003.location = (8948.5830078125, 225.3540802001953)
        separate_xyz_005.location = (9155.25, -5.937835693359375)
        math_025.location = (9411.15625, 181.89195251464844)
        group_input_006.location = (9158.4306640625, -170.32388305664062)
        math_027.location = (9413.009765625, -13.591487884521484)
        position_002.location = (9620.16796875, 239.85662841796875)
        group_input_007.location = (9440.2392578125, 488.8314208984375)
        math_026.location = (9635.3125, 162.71214294433594)
        normal.location = (9838.427734375, 47.40541458129883)
        vector_math_006.location = (10299.1513671875, 160.31515502929688)
        separate_xyz_004.location = (8948.5830078125, 96.436767578125)
        combine_xyz_003.location = (9980.1962890625, -54.27431106567383)
        vector_math_007.location = (10538.458984375, 152.4381103515625)
        vector_math_008.location = (10746.5693359375, 253.31375122070312)
        voronoi_texture.location = (10730.4736328125, -173.17906188964844)
        vector_math_009.location = (10963.8916015625, -219.53811645507812)
        group_input_008.location = (10960.529296875, -470.14727783203125)
        set_position_003.location = (11503.994140625, 48.1038932800293)
        vector_math_010.location = (11254.0947265625, -242.54090881347656)
        subdivide_mesh.location = (7363.05078125, 91.09629821777344)
        reroute_010.location = (7943.5859375, 3.9957542419433594)
        set_position_004.location = (11780.1025390625, 4.811122894287109)
        store_named_attribute.location = (7715.50830078125, 93.45543670654297)
        compare.location = (7494.49169921875, -48.7764892578125)
        separate_xyz_006.location = (7234.60693359375, -289.50152587890625)
        position_003.location = (7032.84814453125, -371.4817199707031)
        boolean_math.location = (11580.7109375, -199.59710693359375)
        named_attribute.location = (11411.0732421875, -368.34375)
        group_input_009.location = (6777.73388671875, -268.3492126464844)
        group_output.location = (12311.607421875, 38.60314178466797)
        sample_index.location = (9880.2099609375, 372.69598388671875)
        sample_index_001.location = (10048.728515625, 180.25819396972656)
        set_shade_smooth.location = (12033.2607421875, 49.22721862792969)
        integer.location = (5027.2509765625, -684.1643676757812)
        resample_curve_001.location = (9660.48046875, 427.8838806152344)

        #Set dimensions
        math.width, math.height = 140.0, 100.0
        math_002.width, math_002.height = 140.0, 100.0
        math_003.width, math_003.height = 140.0, 100.0
        math_004.width, math_004.height = 140.0, 100.0
        group_input.width, group_input.height = 140.0, 100.0
        combine_xyz.width, combine_xyz.height = 140.0, 100.0
        curve_line.width, curve_line.height = 140.0, 100.0
        curve_circle.width, curve_circle.height = 140.0, 100.0
        resample_curve.width, resample_curve.height = 140.0, 100.0
        instance_on_points.width, instance_on_points.height = 140.0, 100.0
        reroute.width, reroute.height = 16.0, 100.0
        math_008.width, math_008.height = 140.0, 100.0
        math_001.width, math_001.height = 140.0, 100.0
        group_input_001.width, group_input_001.height = 140.0, 100.0
        math_007.width, math_007.height = 140.0, 100.0
        duplicate_elements.width, duplicate_elements.height = 140.0, 100.0
        math_010.width, math_010.height = 140.0, 100.0
        reroute_001.width, reroute_001.height = 16.0, 100.0
        reroute_003.width, reroute_003.height = 16.0, 100.0
        reroute_002.width, reroute_002.height = 16.0, 100.0
        combine_xyz_001.width, combine_xyz_001.height = 140.0, 100.0
        math_009.width, math_009.height = 140.0, 100.0
        math_011.width, math_011.height = 140.0, 100.0
        math_005.width, math_005.height = 140.0, 100.0
        realize_instances.width, realize_instances.height = 140.0, 100.0
        vector_math.width, vector_math.height = 140.0, 100.0
        vector_math_001.width, vector_math_001.height = 140.0, 100.0
        bounding_box.width, bounding_box.height = 140.0, 100.0
        vector_math_002.width, vector_math_002.height = 140.0, 100.0
        reroute_004.width, reroute_004.height = 16.0, 100.0
        vector_math_003.width, vector_math_003.height = 140.0, 100.0
        set_position_001.width, set_position_001.height = 140.0, 100.0
        reroute_005.width, reroute_005.height = 16.0, 100.0
        set_position.width, set_position.height = 140.0, 100.0
        reroute_006.width, reroute_006.height = 16.0, 100.0
        fill_curve.width, fill_curve.height = 140.0, 100.0
        scale_instances.width, scale_instances.height = 140.0, 100.0
        group_input_002.width, group_input_002.height = 140.0, 100.0
        separate_xyz.width, separate_xyz.height = 140.0, 100.0
        realize_instances_001.width, realize_instances_001.height = 140.0, 100.0
        bounding_box_001.width, bounding_box_001.height = 140.0, 100.0
        position.width, position.height = 140.0, 100.0
        math_012.width, math_012.height = 140.0, 100.0
        math_013.width, math_013.height = 140.0, 100.0
        math_015.width, math_015.height = 140.0, 100.0
        separate_xyz_001.width, separate_xyz_001.height = 140.0, 100.0
        math_006.width, math_006.height = 140.0, 100.0
        math_018.width, math_018.height = 140.0, 100.0
        math_017.width, math_017.height = 140.0, 100.0
        math_014.width, math_014.height = 140.0, 100.0
        math_020.width, math_020.height = 140.0, 100.0
        separate_xyz_002.width, separate_xyz_002.height = 140.0, 100.0
        math_019.width, math_019.height = 140.0, 100.0
        math_022.width, math_022.height = 140.0, 100.0
        math_016.width, math_016.height = 140.0, 100.0
        math_021.width, math_021.height = 140.0, 100.0
        combine_xyz_002.width, combine_xyz_002.height = 140.0, 100.0
        reroute_007.width, reroute_007.height = 16.0, 100.0
        set_position_002.width, set_position_002.height = 140.0, 100.0
        vector_math_004.width, vector_math_004.height = 140.0, 100.0
        random_value.width, random_value.height = 140.0, 100.0
        math_023.width, math_023.height = 140.0, 100.0
        extrude_mesh.width, extrude_mesh.height = 140.0, 100.0
        group_input_005.width, group_input_005.height = 140.0, 100.0
        group_input_004.width, group_input_004.height = 140.0, 100.0
        reroute_008.width, reroute_008.height = 16.0, 100.0
        reroute_009.width, reroute_009.height = 16.0, 100.0
        position_001.width, position_001.height = 140.0, 100.0
        bounding_box_002.width, bounding_box_002.height = 140.0, 100.0
        vector_math_005.width, vector_math_005.height = 140.0, 100.0
        math_024.width, math_024.height = 140.0, 100.0
        separate_xyz_003.width, separate_xyz_003.height = 140.0, 100.0
        separate_xyz_005.width, separate_xyz_005.height = 140.0, 100.0
        math_025.width, math_025.height = 140.0, 100.0
        group_input_006.width, group_input_006.height = 140.0, 100.0
        math_027.width, math_027.height = 140.0, 100.0
        position_002.width, position_002.height = 140.0, 100.0
        group_input_007.width, group_input_007.height = 140.0, 100.0
        math_026.width, math_026.height = 140.0, 100.0
        normal.width, normal.height = 140.0, 100.0
        vector_math_006.width, vector_math_006.height = 140.0, 100.0
        separate_xyz_004.width, separate_xyz_004.height = 140.0, 100.0
        combine_xyz_003.width, combine_xyz_003.height = 140.0, 100.0
        vector_math_007.width, vector_math_007.height = 140.0, 100.0
        vector_math_008.width, vector_math_008.height = 140.0, 100.0
        voronoi_texture.width, voronoi_texture.height = 140.0, 100.0
        vector_math_009.width, vector_math_009.height = 140.0, 100.0
        group_input_008.width, group_input_008.height = 140.0, 100.0
        set_position_003.width, set_position_003.height = 140.0, 100.0
        vector_math_010.width, vector_math_010.height = 140.0, 100.0
        subdivide_mesh.width, subdivide_mesh.height = 140.0, 100.0
        reroute_010.width, reroute_010.height = 16.0, 100.0
        set_position_004.width, set_position_004.height = 140.0, 100.0
        store_named_attribute.width, store_named_attribute.height = 140.0, 100.0
        compare.width, compare.height = 140.0, 100.0
        separate_xyz_006.width, separate_xyz_006.height = 140.0, 100.0
        position_003.width, position_003.height = 140.0, 100.0
        boolean_math.width, boolean_math.height = 140.0, 100.0
        named_attribute.width, named_attribute.height = 140.0, 100.0
        group_input_009.width, group_input_009.height = 140.0, 100.0
        group_output.width, group_output.height = 140.0, 100.0
        sample_index.width, sample_index.height = 140.0, 100.0
        sample_index_001.width, sample_index_001.height = 140.0, 100.0
        set_shade_smooth.width, set_shade_smooth.height = 140.0, 100.0
        integer.width, integer.height = 140.0, 100.0
        resample_curve_001.width, resample_curve_001.height = 140.0, 100.0

        #initialize my_generator links
        #group_input.Block Width -> math.Value
        my_generator.links.new(group_input.outputs[1], math.inputs[1])
        #math_001.Value -> math.Value
        my_generator.links.new(math_001.outputs[0], math.inputs[0])
        #math.Value -> math_002.Value
        my_generator.links.new(math.outputs[0], math_002.inputs[0])
        #math_002.Value -> math_003.Value
        my_generator.links.new(math_002.outputs[0], math_003.inputs[0])
        #math_004.Value -> math_003.Value
        my_generator.links.new(math_004.outputs[0], math_003.inputs[1])
        #group_input.Block Count -> math_004.Value
        my_generator.links.new(group_input.outputs[2], math_004.inputs[0])
        #math_003.Value -> combine_xyz.Y
        my_generator.links.new(math_003.outputs[0], combine_xyz.inputs[1])
        #combine_xyz.Vector -> curve_line.End
        my_generator.links.new(combine_xyz.outputs[0], curve_line.inputs[1])
        #curve_line.Curve -> resample_curve.Curve
        my_generator.links.new(curve_line.outputs[0], resample_curve.inputs[0])
        #resample_curve.Curve -> instance_on_points.Points
        my_generator.links.new(resample_curve.outputs[0], instance_on_points.inputs[0])
        #curve_circle.Curve -> instance_on_points.Instance
        my_generator.links.new(curve_circle.outputs[0], instance_on_points.inputs[2])
        #group_input_001.Block Count -> resample_curve.Count
        my_generator.links.new(group_input_001.outputs[2], resample_curve.inputs[2])
        #group_input_001.Block Width -> curve_circle.Radius
        my_generator.links.new(group_input_001.outputs[1], curve_circle.inputs[4])
        #instance_on_points.Instances -> duplicate_elements.Geometry
        my_generator.links.new(instance_on_points.outputs[0], duplicate_elements.inputs[0])
        #group_input_001.Rows -> reroute.Input
        my_generator.links.new(group_input_001.outputs[4], reroute.inputs[0])
        #reroute.Output -> duplicate_elements.Amount
        my_generator.links.new(reroute.outputs[0], duplicate_elements.inputs[2])
        #duplicate_elements.Geometry -> set_position.Geometry
        my_generator.links.new(duplicate_elements.outputs[0], set_position.inputs[0])
        #duplicate_elements.Duplicate Index -> math_005.Value
        my_generator.links.new(duplicate_elements.outputs[1], math_005.inputs[0])
        #math_008.Value -> math_007.Value
        my_generator.links.new(math_008.outputs[0], math_007.inputs[0])
        #reroute_001.Output -> math_007.Value
        my_generator.links.new(reroute_001.outputs[0], math_007.inputs[1])
        #duplicate_elements.Duplicate Index -> math_009.Value
        my_generator.links.new(duplicate_elements.outputs[1], math_009.inputs[0])
        #math_009.Value -> math_010.Value
        my_generator.links.new(math_009.outputs[0], math_010.inputs[0])
        #group_input_001.Block Width -> reroute_001.Input
        my_generator.links.new(group_input_001.outputs[1], reroute_001.inputs[0])
        #reroute_001.Output -> reroute_002.Input
        my_generator.links.new(reroute_001.outputs[0], reroute_002.inputs[0])
        #reroute_003.Output -> math_010.Value
        my_generator.links.new(reroute_003.outputs[0], math_010.inputs[1])
        #reroute_002.Output -> reroute_003.Input
        my_generator.links.new(reroute_002.outputs[0], reroute_003.inputs[0])
        #math_010.Value -> combine_xyz_001.X
        my_generator.links.new(math_010.outputs[0], combine_xyz_001.inputs[0])
        #combine_xyz_001.Vector -> set_position.Offset
        my_generator.links.new(combine_xyz_001.outputs[0], set_position.inputs[3])
        #math_005.Value -> math_011.Value
        my_generator.links.new(math_005.outputs[0], math_011.inputs[0])
        #math_007.Value -> math_011.Value
        my_generator.links.new(math_007.outputs[0], math_011.inputs[1])
        #math_011.Value -> combine_xyz_001.Y
        my_generator.links.new(math_011.outputs[0], combine_xyz_001.inputs[1])
        #set_position.Geometry -> realize_instances.Geometry
        my_generator.links.new(set_position.outputs[0], realize_instances.inputs[0])
        #realize_instances.Geometry -> bounding_box.Geometry
        my_generator.links.new(realize_instances.outputs[0], bounding_box.inputs[0])
        #bounding_box.Min -> vector_math.Vector
        my_generator.links.new(bounding_box.outputs[1], vector_math.inputs[1])
        #bounding_box.Max -> vector_math.Vector
        my_generator.links.new(bounding_box.outputs[2], vector_math.inputs[0])
        #vector_math.Vector -> vector_math_001.Vector
        my_generator.links.new(vector_math.outputs[0], vector_math_001.inputs[0])
        #bounding_box.Min -> reroute_004.Input
        my_generator.links.new(bounding_box.outputs[1], reroute_004.inputs[0])
        #reroute_004.Output -> vector_math_002.Vector
        my_generator.links.new(reroute_004.outputs[0], vector_math_002.inputs[0])
        #vector_math_001.Vector -> vector_math_002.Vector
        my_generator.links.new(vector_math_001.outputs[0], vector_math_002.inputs[1])
        #vector_math_002.Vector -> vector_math_003.Vector
        my_generator.links.new(vector_math_002.outputs[0], vector_math_003.inputs[0])
        #vector_math_003.Vector -> set_position_001.Offset
        my_generator.links.new(vector_math_003.outputs[0], set_position_001.inputs[3])
        #reroute_005.Output -> set_position_001.Geometry
        my_generator.links.new(reroute_005.outputs[0], set_position_001.inputs[0])
        #set_position.Geometry -> reroute_006.Input
        my_generator.links.new(set_position.outputs[0], reroute_006.inputs[0])
        #reroute_006.Output -> reroute_005.Input
        my_generator.links.new(reroute_006.outputs[0], reroute_005.inputs[0])
        #set_position_001.Geometry -> fill_curve.Curve
        my_generator.links.new(set_position_001.outputs[0], fill_curve.inputs[0])
        #fill_curve.Mesh -> scale_instances.Instances
        my_generator.links.new(fill_curve.outputs[0], scale_instances.inputs[0])
        #group_input_002.Block Scale -> scale_instances.Scale
        my_generator.links.new(group_input_002.outputs[5], scale_instances.inputs[2])
        #scale_instances.Instances -> realize_instances_001.Geometry
        my_generator.links.new(scale_instances.outputs[0], realize_instances_001.inputs[0])
        #realize_instances_001.Geometry -> bounding_box_001.Geometry
        my_generator.links.new(realize_instances_001.outputs[0], bounding_box_001.inputs[0])
        #bounding_box_001.Min -> separate_xyz.Vector
        my_generator.links.new(bounding_box_001.outputs[1], separate_xyz.inputs[0])
        #bounding_box_001.Max -> separate_xyz_001.Vector
        my_generator.links.new(bounding_box_001.outputs[2], separate_xyz_001.inputs[0])
        #position.Position -> separate_xyz_002.Vector
        my_generator.links.new(position.outputs[0], separate_xyz_002.inputs[0])
        #math_012.Value -> math_006.Value
        my_generator.links.new(math_012.outputs[0], math_006.inputs[0])
        #math_013.Value -> math_014.Value
        my_generator.links.new(math_013.outputs[0], math_014.inputs[0])
        #separate_xyz.X -> math_015.Value
        my_generator.links.new(separate_xyz.outputs[0], math_015.inputs[0])
        #math_006.Value -> math_015.Value
        my_generator.links.new(math_006.outputs[0], math_015.inputs[1])
        #separate_xyz.Y -> math_016.Value
        my_generator.links.new(separate_xyz.outputs[1], math_016.inputs[0])
        #math_014.Value -> math_016.Value
        my_generator.links.new(math_014.outputs[0], math_016.inputs[1])
        #separate_xyz_001.X -> math_017.Value
        my_generator.links.new(separate_xyz_001.outputs[0], math_017.inputs[0])
        #math_006.Value -> math_017.Value
        my_generator.links.new(math_006.outputs[0], math_017.inputs[1])
        #separate_xyz_001.Y -> math_018.Value
        my_generator.links.new(separate_xyz_001.outputs[1], math_018.inputs[0])
        #math_014.Value -> math_018.Value
        my_generator.links.new(math_014.outputs[0], math_018.inputs[1])
        #math_017.Value -> math_019.Value
        my_generator.links.new(math_017.outputs[0], math_019.inputs[0])
        #separate_xyz_002.X -> math_019.Value
        my_generator.links.new(separate_xyz_002.outputs[0], math_019.inputs[1])
        #separate_xyz_002.Y -> math_020.Value
        my_generator.links.new(separate_xyz_002.outputs[1], math_020.inputs[0])
        #math_018.Value -> math_020.Value
        my_generator.links.new(math_018.outputs[0], math_020.inputs[1])
        #math_015.Value -> math_021.Value
        my_generator.links.new(math_015.outputs[0], math_021.inputs[0])
        #math_019.Value -> math_021.Value
        my_generator.links.new(math_019.outputs[0], math_021.inputs[1])
        #math_020.Value -> math_022.Value
        my_generator.links.new(math_020.outputs[0], math_022.inputs[0])
        #math_016.Value -> math_022.Value
        my_generator.links.new(math_016.outputs[0], math_022.inputs[1])
        #math_021.Value -> combine_xyz_002.X
        my_generator.links.new(math_021.outputs[0], combine_xyz_002.inputs[0])
        #math_022.Value -> combine_xyz_002.Y
        my_generator.links.new(math_022.outputs[0], combine_xyz_002.inputs[1])
        #combine_xyz_002.Vector -> set_position_002.Position
        my_generator.links.new(combine_xyz_002.outputs[0], set_position_002.inputs[2])
        #realize_instances_001.Geometry -> reroute_007.Input
        my_generator.links.new(realize_instances_001.outputs[0], reroute_007.inputs[0])
        #reroute_007.Output -> set_position_002.Geometry
        my_generator.links.new(reroute_007.outputs[0], set_position_002.inputs[0])
        #set_position_002.Geometry -> extrude_mesh.Mesh
        my_generator.links.new(set_position_002.outputs[0], extrude_mesh.inputs[0])
        #vector_math_004.Vector -> extrude_mesh.Offset
        my_generator.links.new(vector_math_004.outputs[0], extrude_mesh.inputs[2])
        #random_value.Value -> vector_math_004.Vector
        my_generator.links.new(random_value.outputs[0], vector_math_004.inputs[1])
        #math_023.Value -> random_value.Min
        my_generator.links.new(math_023.outputs[0], random_value.inputs[0])
        #group_input_004.Extrude -> math_023.Value
        my_generator.links.new(group_input_004.outputs[6], math_023.inputs[1])
        #extrude_mesh.Mesh -> subdivide_mesh.Mesh
        my_generator.links.new(extrude_mesh.outputs[0], subdivide_mesh.inputs[0])
        #group_input_005.Level detalise -> subdivide_mesh.Level
        my_generator.links.new(group_input_005.outputs[3], subdivide_mesh.inputs[1])
        #reroute_010.Output -> reroute_008.Input
        my_generator.links.new(reroute_010.outputs[0], reroute_008.inputs[0])
        #reroute_008.Output -> reroute_009.Input
        my_generator.links.new(reroute_008.outputs[0], reroute_009.inputs[0])
        #set_shade_smooth.Geometry -> group_output.Geometry
        my_generator.links.new(set_shade_smooth.outputs[0], group_output.inputs[0])
        #reroute_010.Output -> bounding_box_002.Geometry
        my_generator.links.new(reroute_010.outputs[0], bounding_box_002.inputs[0])
        #bounding_box_002.Min -> separate_xyz_003.Vector
        my_generator.links.new(bounding_box_002.outputs[1], separate_xyz_003.inputs[0])
        #position_001.Position -> separate_xyz_004.Vector
        my_generator.links.new(position_001.outputs[0], separate_xyz_004.inputs[0])
        #bounding_box_002.Max -> vector_math_005.Vector
        my_generator.links.new(bounding_box_002.outputs[2], vector_math_005.inputs[0])
        #bounding_box_002.Min -> vector_math_005.Vector
        my_generator.links.new(bounding_box_002.outputs[1], vector_math_005.inputs[1])
        #vector_math_005.Vector -> separate_xyz_005.Vector
        my_generator.links.new(vector_math_005.outputs[0], separate_xyz_005.inputs[0])
        #separate_xyz_004.Y -> math_024.Value
        my_generator.links.new(separate_xyz_004.outputs[1], math_024.inputs[0])
        #separate_xyz_003.Y -> math_024.Value
        my_generator.links.new(separate_xyz_003.outputs[1], math_024.inputs[1])
        #math_024.Value -> math_025.Value
        my_generator.links.new(math_024.outputs[0], math_025.inputs[0])
        #separate_xyz_005.Y -> math_025.Value
        my_generator.links.new(separate_xyz_005.outputs[1], math_025.inputs[1])
        #math_025.Value -> math_026.Value
        my_generator.links.new(math_025.outputs[0], math_026.inputs[0])
        #math_027.Value -> math_026.Value
        my_generator.links.new(math_027.outputs[0], math_026.inputs[1])
        #math_026.Value -> sample_index.Index
        my_generator.links.new(math_026.outputs[0], sample_index.inputs[6])
        #position_002.Position -> sample_index.Value
        my_generator.links.new(position_002.outputs[0], sample_index.inputs[3])
        #resample_curve_001.Curve -> sample_index.Geometry
        my_generator.links.new(resample_curve_001.outputs[0], sample_index.inputs[0])
        #group_input_007.Geometry -> resample_curve_001.Curve
        my_generator.links.new(group_input_007.outputs[0], resample_curve_001.inputs[0])
        #resample_curve_001.Curve -> sample_index_001.Geometry
        my_generator.links.new(resample_curve_001.outputs[0], sample_index_001.inputs[0])
        #math_026.Value -> sample_index_001.Index
        my_generator.links.new(math_026.outputs[0], sample_index_001.inputs[6])
        #normal.Normal -> sample_index_001.Value
        my_generator.links.new(normal.outputs[0], sample_index_001.inputs[3])
        #sample_index_001.Value -> vector_math_006.Vector
        my_generator.links.new(sample_index_001.outputs[2], vector_math_006.inputs[0])
        #separate_xyz_004.X -> vector_math_006.Vector
        my_generator.links.new(separate_xyz_004.outputs[0], vector_math_006.inputs[1])
        #separate_xyz_004.Z -> combine_xyz_003.Z
        my_generator.links.new(separate_xyz_004.outputs[2], combine_xyz_003.inputs[2])
        #combine_xyz_003.Vector -> vector_math_007.Vector
        my_generator.links.new(combine_xyz_003.outputs[0], vector_math_007.inputs[1])
        #vector_math_006.Vector -> vector_math_007.Vector
        my_generator.links.new(vector_math_006.outputs[0], vector_math_007.inputs[0])
        #sample_index.Value -> vector_math_008.Vector
        my_generator.links.new(sample_index.outputs[2], vector_math_008.inputs[0])
        #vector_math_007.Vector -> vector_math_008.Vector
        my_generator.links.new(vector_math_007.outputs[0], vector_math_008.inputs[1])
        #reroute_009.Output -> set_position_003.Geometry
        my_generator.links.new(reroute_009.outputs[0], set_position_003.inputs[0])
        #vector_math_008.Vector -> set_position_003.Position
        my_generator.links.new(vector_math_008.outputs[0], set_position_003.inputs[2])
        #voronoi_texture.Color -> vector_math_009.Vector
        my_generator.links.new(voronoi_texture.outputs[1], vector_math_009.inputs[0])
        #vector_math_009.Vector -> vector_math_010.Vector
        my_generator.links.new(vector_math_009.outputs[0], vector_math_010.inputs[0])
        #group_input_008.Rougress -> vector_math_010.Scale
        my_generator.links.new(group_input_008.outputs[7], vector_math_010.inputs[3])
        #set_position_003.Geometry -> set_position_004.Geometry
        my_generator.links.new(set_position_003.outputs[0], set_position_004.inputs[0])
        #vector_math_010.Vector -> set_position_004.Offset
        my_generator.links.new(vector_math_010.outputs[0], set_position_004.inputs[3])
        #store_named_attribute.Geometry -> reroute_010.Input
        my_generator.links.new(store_named_attribute.outputs[0], reroute_010.inputs[0])
        #subdivide_mesh.Mesh -> store_named_attribute.Geometry
        my_generator.links.new(subdivide_mesh.outputs[0], store_named_attribute.inputs[0])
        #compare.Result -> store_named_attribute.Value
        my_generator.links.new(compare.outputs[0], store_named_attribute.inputs[4])
        #separate_xyz_006.Z -> compare.A
        my_generator.links.new(separate_xyz_006.outputs[2], compare.inputs[0])
        #position_003.Position -> separate_xyz_006.Vector
        my_generator.links.new(position_003.outputs[0], separate_xyz_006.inputs[0])
        #boolean_math.Boolean -> set_position_004.Selection
        my_generator.links.new(boolean_math.outputs[0], set_position_004.inputs[1])
        #named_attribute.Attribute -> boolean_math.Boolean
        my_generator.links.new(named_attribute.outputs[1], boolean_math.inputs[0])
        #group_input_009.Height -> extrude_mesh.Offset Scale
        my_generator.links.new(group_input_009.outputs[8], extrude_mesh.inputs[3])
        #set_position_004.Geometry -> set_shade_smooth.Geometry
        my_generator.links.new(set_position_004.outputs[0], set_shade_smooth.inputs[0])
        #integer.Integer -> math_014.Value
        my_generator.links.new(integer.outputs[0], math_014.inputs[1])
        #integer.Integer -> math_006.Value
        my_generator.links.new(integer.outputs[0], math_006.inputs[1])
        return my_generator

        return my_generator
    return bpy.data.node_groups["My Generator"]

def create_node_group():
    return my_generator_node_group()




