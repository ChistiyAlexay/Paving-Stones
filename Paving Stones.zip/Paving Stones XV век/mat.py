import bpy

def create_stone_material():
    mat = bpy.data.materials.new(name = "StonePaving")
    mat.use_nodes = True
    stone = mat.node_tree
    for node in stone.nodes:
        stone.nodes.remove(node)
    

    #initialize stone nodes
    #node Principled BSDF
    principled_bsdf = stone.nodes.new("ShaderNodeBsdfPrincipled")
    principled_bsdf.name = "Principled BSDF"
    principled_bsdf.distribution = 'GGX'
    principled_bsdf.subsurface_method = 'RANDOM_WALK'
    #Subsurface
    principled_bsdf.inputs[1].default_value = 0.0
    #Subsurface Radius
    principled_bsdf.inputs[2].default_value = (1.0, 0.20000000298023224, 0.10000000149011612)
    #Subsurface Color
    principled_bsdf.inputs[3].default_value = (0.800000011920929, 0.800000011920929, 0.800000011920929, 1.0)
    #Subsurface IOR
    principled_bsdf.inputs[4].default_value = 1.399999976158142
    #Subsurface Anisotropy
    principled_bsdf.inputs[5].default_value = 0.0
    #Metallic
    principled_bsdf.inputs[6].default_value = 0.0
    #Specular
    principled_bsdf.inputs[7].default_value = 0.5
    #Specular Tint
    principled_bsdf.inputs[8].default_value = 0.0
    #Roughness
    principled_bsdf.inputs[9].default_value = 0.5
    #Anisotropic
    principled_bsdf.inputs[10].default_value = 0.0
    #Anisotropic Rotation
    principled_bsdf.inputs[11].default_value = 0.0
    #Sheen
    principled_bsdf.inputs[12].default_value = 0.0
    #Sheen Tint
    principled_bsdf.inputs[13].default_value = 0.5
    #Clearcoat
    principled_bsdf.inputs[14].default_value = 0.0
    #Clearcoat Roughness
    principled_bsdf.inputs[15].default_value = 0.029999999329447746
    #IOR
    principled_bsdf.inputs[16].default_value = 1.4500000476837158
    #Transmission
    principled_bsdf.inputs[17].default_value = 0.0
    #Transmission Roughness
    principled_bsdf.inputs[18].default_value = 0.0
    #Emission
    principled_bsdf.inputs[19].default_value = (0.0, 0.0, 0.0, 1.0)
    #Emission Strength
    principled_bsdf.inputs[20].default_value = 1.0
    #Alpha
    principled_bsdf.inputs[21].default_value = 1.0
    #Clearcoat Normal
    principled_bsdf.inputs[23].default_value = (0.0, 0.0, 0.0)
    #Tangent
    principled_bsdf.inputs[24].default_value = (0.0, 0.0, 0.0)

    #node Material Output
    material_output = stone.nodes.new("ShaderNodeOutputMaterial")
    material_output.name = "Material Output"
    material_output.is_active_output = True
    material_output.target = 'ALL'
    #Displacement
    material_output.inputs[2].default_value = (0.0, 0.0, 0.0)

    #node Mix
    mix = stone.nodes.new("ShaderNodeMix")
    mix.name = "Mix"
    mix.blend_type = 'MIX'
    mix.clamp_factor = True
    mix.clamp_result = False
    mix.data_type = 'RGBA'
    mix.factor_mode = 'UNIFORM'
    #Factor_Float
    mix.inputs[0].default_value = 0.5249999761581421

    #node Color Ramp
    color_ramp = stone.nodes.new("ShaderNodeValToRGB")
    color_ramp.name = "Color Ramp"
    color_ramp.color_ramp.color_mode = 'RGB'
    color_ramp.color_ramp.hue_interpolation = 'NEAR'
    color_ramp.color_ramp.interpolation = 'LINEAR'

    #initialize color ramp elements
    color_ramp.color_ramp.elements.remove(color_ramp.color_ramp.elements[0])
    color_ramp_cre_0 = color_ramp.color_ramp.elements[0]
    color_ramp_cre_0.position = 0.0
    color_ramp_cre_0.alpha = 1.0
    color_ramp_cre_0.color = (0.15538999438285828, 0.15538999438285828, 0.15538999438285828, 1.0)

    color_ramp_cre_1 = color_ramp.color_ramp.elements.new(1.0)
    color_ramp_cre_1.alpha = 1.0
    color_ramp_cre_1.color = (0.014639999717473984, 0.014639999717473984, 0.014639999717473984, 1.0)


    #node Bump
    bump = stone.nodes.new("ShaderNodeBump")
    bump.name = "Bump"
    bump.invert = False
    #Strength
    bump.inputs[0].default_value = 0.42500001192092896
    #Distance
    bump.inputs[1].default_value = 1.0
    #Normal
    bump.inputs[3].default_value = (0.0, 0.0, 0.0)

    #node Voronoi Texture
    voronoi_texture = stone.nodes.new("ShaderNodeTexVoronoi")
    voronoi_texture.name = "Voronoi Texture"
    voronoi_texture.distance = 'EUCLIDEAN'
    voronoi_texture.feature = 'F1'
    voronoi_texture.voronoi_dimensions = '3D'
    #Scale
    voronoi_texture.inputs[2].default_value = 2.0999999046325684
    #Randomness
    voronoi_texture.inputs[5].default_value = 1.0

    #node Noise Texture
    noise_texture = stone.nodes.new("ShaderNodeTexNoise")
    noise_texture.name = "Noise Texture"
    noise_texture.noise_dimensions = '3D'
    #Scale
    noise_texture.inputs[2].default_value = 5.0
    #Detail
    noise_texture.inputs[3].default_value = 2.0
    #Roughness
    noise_texture.inputs[4].default_value = 0.5
    #Distortion
    noise_texture.inputs[5].default_value = 0.0

    #node Color Ramp.001
    color_ramp_001 = stone.nodes.new("ShaderNodeValToRGB")
    color_ramp_001.name = "Color Ramp.001"
    color_ramp_001.color_ramp.color_mode = 'RGB'
    color_ramp_001.color_ramp.hue_interpolation = 'NEAR'
    color_ramp_001.color_ramp.interpolation = 'LINEAR'

    #initialize color ramp elements
    color_ramp_001.color_ramp.elements.remove(color_ramp_001.color_ramp.elements[0])
    color_ramp_001_cre_0 = color_ramp_001.color_ramp.elements[0]
    color_ramp_001_cre_0.position = 0.0
    color_ramp_001_cre_0.alpha = 1.0
    color_ramp_001_cre_0.color = (0.15538999438285828, 0.15538999438285828, 0.15538999438285828, 1.0)

    color_ramp_001_cre_1 = color_ramp_001.color_ramp.elements.new(0.0227269995957613)
    color_ramp_001_cre_1.alpha = 1.0
    color_ramp_001_cre_1.color = (1.0, 1.0, 1.0, 1.0)


    #node Texture Coordinate
    texture_coordinate = stone.nodes.new("ShaderNodeTexCoord")
    texture_coordinate.name = "Texture Coordinate"
    texture_coordinate.from_instancer = False

    #node Noise Texture.001
    noise_texture_001 = stone.nodes.new("ShaderNodeTexNoise")
    noise_texture_001.name = "Noise Texture.001"
    noise_texture_001.noise_dimensions = '3D'
    #Scale
    noise_texture_001.inputs[2].default_value = 5.0
    #Detail
    noise_texture_001.inputs[3].default_value = 3.700000047683716
    #Roughness
    noise_texture_001.inputs[4].default_value = 0.824999988079071
    #Distortion
    noise_texture_001.inputs[5].default_value = 0.0

    #node Voronoi Texture.001
    voronoi_texture_001 = stone.nodes.new("ShaderNodeTexVoronoi")
    voronoi_texture_001.name = "Voronoi Texture.001"
    voronoi_texture_001.distance = 'EUCLIDEAN'
    voronoi_texture_001.feature = 'DISTANCE_TO_EDGE'
    voronoi_texture_001.voronoi_dimensions = '3D'
    #Scale
    voronoi_texture_001.inputs[2].default_value = 1.100000023841858
    #Randomness
    voronoi_texture_001.inputs[5].default_value = 1.0


    #Set locations
    principled_bsdf.location = (10.0, 300.0)
    material_output.location = (300.0, 300.0)
    mix.location = (-218.33920288085938, 241.11900329589844)
    color_ramp.location = (-533.7572631835938, 286.7799072265625)
    bump.location = (-228.72662353515625, -117.66322326660156)
    voronoi_texture.location = (-780.5912475585938, 236.02134704589844)
    noise_texture.location = (-997.1267700195312, 274.0624694824219)
    color_ramp_001.location = (-521.3045654296875, -29.01819610595703)
    texture_coordinate.location = (-1246.031982421875, 332.27557373046875)
    noise_texture_001.location = (-1013.9999389648438, -1.6596527099609375)
    voronoi_texture_001.location = (-797.4644165039062, -39.700775146484375)

    #Set dimensions
    principled_bsdf.width, principled_bsdf.height = 240.0, 100.0
    material_output.width, material_output.height = 140.0, 100.0
    mix.width, mix.height = 140.0, 100.0
    color_ramp.width, color_ramp.height = 240.0, 100.0
    bump.width, bump.height = 140.0, 100.0
    voronoi_texture.width, voronoi_texture.height = 140.0, 100.0
    noise_texture.width, noise_texture.height = 140.0, 100.0
    color_ramp_001.width, color_ramp_001.height = 240.0, 100.0
    texture_coordinate.width, texture_coordinate.height = 140.0, 100.0
    noise_texture_001.width, noise_texture_001.height = 140.0, 100.0
    voronoi_texture_001.width, voronoi_texture_001.height = 140.0, 100.0

    #initialize stone links
    #principled_bsdf.BSDF -> material_output.Surface
    stone.links.new(principled_bsdf.outputs[0], material_output.inputs[0])
    #mix.Result -> principled_bsdf.Base Color
    stone.links.new(mix.outputs[2], principled_bsdf.inputs[0])
    #color_ramp.Color -> mix.A
    stone.links.new(color_ramp.outputs[0], mix.inputs[6])
    #bump.Normal -> principled_bsdf.Normal
    stone.links.new(bump.outputs[0], principled_bsdf.inputs[22])
    #color_ramp_001.Color -> bump.Height
    stone.links.new(color_ramp_001.outputs[0], bump.inputs[2])
    #voronoi_texture.Distance -> color_ramp.Fac
    stone.links.new(voronoi_texture.outputs[0], color_ramp.inputs[0])
    #noise_texture.Color -> voronoi_texture.Vector
    stone.links.new(noise_texture.outputs[1], voronoi_texture.inputs[0])
    #texture_coordinate.Object -> noise_texture.Vector
    stone.links.new(texture_coordinate.outputs[3], noise_texture.inputs[0])
    #noise_texture_001.Color -> voronoi_texture_001.Vector
    stone.links.new(noise_texture_001.outputs[1], voronoi_texture_001.inputs[0])
    #texture_coordinate.Object -> noise_texture_001.Vector
    stone.links.new(texture_coordinate.outputs[3], noise_texture_001.inputs[0])
    #voronoi_texture_001.Distance -> color_ramp_001.Fac
    stone.links.new(voronoi_texture_001.outputs[0], color_ramp_001.inputs[0])
    #voronoi_texture_001.Distance -> mix.B
    stone.links.new(voronoi_texture_001.outputs[0], mix.inputs[7])
    return stone

    stone = stone_node_group()

    return mat
