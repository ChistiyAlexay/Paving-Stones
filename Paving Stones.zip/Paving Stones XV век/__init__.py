bl_info = {
    "name": "Paving Stones",
    "author": "Alexey",
    "version": (0, 1),
    "blender": (3, 3, 0),
    "category": "Object",
}
from gen import create_node_group  
from mat import create_stone_material  
import bpy
from bpy.props import (
    StringProperty,
    BoolProperty,
    IntProperty,
    FloatProperty,
    FloatVectorProperty,
    EnumProperty,
)
from bpy.types import Operator, Panel

class OBJECT_OT_add_bezier_curve(bpy.types.Operator):
    bl_idname = "object.add_bezier_curve"
    bl_label = "Generate"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):

        bpy.ops.curve.primitive_bezier_curve_add()
        bezier_curve = bpy.context.object
        material = create_stone_material()
        curve = bpy.context.object
        self.apply_material(curve)  
        
     
        bezier_curve.data.splines[0].bezier_points[0].co = (0, 0, 0)  
        bezier_curve.data.splines[0].bezier_points[1].co = (5, 0, 0) 


        for point in bezier_curve.data.splines[0].bezier_points:
            point.handle_left_type = 'AUTO'
            point.handle_right_type = 'AUTO'


        geometry_node_modifier = bezier_curve.modifiers.new(name="Geometry Nodes", type='NODES')


        my_generator = create_node_group()  
        if my_generator is not None:
            geometry_node_modifier.node_group = my_generator
            self.report({'INFO'}, f"Done!")
        else:
            self.report({'ERROR'}, f"Error")

        return {'FINISHED'}

    def apply_material(self, obj):
        material_name = "StonePaving"
        if material_name not in bpy.data.materials:
            material = bpy.data.materials.new(name=material_name)
        else:
            material = bpy.data.materials[material_name]

       
        material.use_nodes = True
        bsdf = material.node_tree.nodes.get("Principled BSDF")
        if bsdf:
         
            bsdf.inputs['Base Color'].default_value = (0.5, 0.5, 0.5, 1)  

   
        if obj.data.materials:
            obj.data.materials[0] = material
        else:
            obj.data.materials.append(material)

class OBJECT_OT_convert_to_mesh(bpy.types.Operator):
    """Конвертировать объект в меш"""
    bl_idname = "object.convert_to_mesh"
    bl_label = "Convert to Mesh"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        
        obj = bpy.context.object

        
        if obj is None or obj.type != 'CURVE':
            self.report({'ERROR'}, "Select the curve to convert")
            return {'CANCELLED'}


        bpy.ops.object.convert(target='MESH')
        self.report({'INFO'}, "The object has been successfully converted to mesh")
        return {'FINISHED'}

class OBJECT_OT_apply_material(bpy.types.Operator):
    """Применить материал к объекту"""
    bl_idname = "object.apply_material"
    bl_label = "Apply the Material"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):

        obj = bpy.context.object

      
        if obj is None:
            self.report({'ERROR'}, "Select the object to apply the material to")
            return {'CANCELLED'}

     
        self.apply_material(obj)
        self.report({'INFO'}, "The material has been successfully applied")
        return {'FINISHED'}

    def apply_material(self, obj):
        material_name = "StonePaving"
        material = bpy.data.materials[material_name]
        material.use_nodes = True
        bsdf = material.node_tree.nodes.get("Principled BSDF")
        if bsdf:
           
            bsdf.inputs['Base Color'].default_value = (0.5, 0.5, 0.5, 1) 

       
        if obj.data.materials:
            obj.data.materials[0] = material
        else:
            obj.data.materials.append(material)


class OBJECT_OT_combine_objects(bpy.types.Operator):
    bl_idname = "object.combine_objects"
    bl_label = "Merge objects"
    
    def execute(self, context):
        objects_to_join = [obj for obj in bpy.data.objects if obj.name.startswith("Cube_cell")]
        objects_to_join = objects_to_join[:500]
        for obj in objects_to_join:
            obj.select_set(True)
        if objects_to_join:
            context.view_layer.objects.active = objects_to_join[0]
            bpy.ops.object.join()
            context.active_object.name = "Paving Stones"
        else:
            self.report({'WARNING'}, "There are no objects to combine with the prefix: Cube_cell")
        return {'FINISHED'}

class OBJECT_OT_add_modifiers(bpy.types.Operator):
    bl_idname = "object.add_modifiers"
    bl_label = "Add modifiers"
    
    def execute(self, context):
        obj = context.active_object
        if obj:
            scene = context.scene
            displace_modifier = obj.modifiers.new(name="Displace", type='DISPLACE')
            displace_modifier.strength = 0.5
            displace_modifier.mid_level = scene.midlevel
            texture = bpy.data.textures.new(name="Cloud Texture", type='CLOUDS')
            displace_modifier.texture = texture
            displace_modifier.texture_coords = 'GLOBAL'
            subdiv_modifier = obj.modifiers.new(name="Subdivision", type='SUBSURF')
            decimate_modifier = obj.modifiers.new(name="Decimate", type='DECIMATE')
            decimate_modifier.ratio = 0.13
            subdiv_modifier_2 = obj.modifiers.new(name="Subdivision 2", type='SUBSURF')
            subdiv_modifier_2.levels = 2
            bevel_modifier = obj.modifiers.new(name="Bevel", type='BEVEL')
            bevel_modifier.limit_method = 'NONE'
            bpy.ops.object.modifier_apply(modifier=displace_modifier.name)
            bpy.ops.object.modifier_apply(modifier=subdiv_modifier.name)
            bpy.ops.object.modifier_apply(modifier=decimate_modifier.name)
            bpy.ops.object.modifier_apply(modifier=subdiv_modifier_2.name)
            bpy.ops.object.modifier_apply(modifier=bevel_modifier.name)
            bpy.ops.object.shade_smooth()
        return {'FINISHED'}

class OBJECT_OT_create_cube(bpy.types.Operator):
    bl_idname = "object.create_cube"
    bl_label = "Create a blank"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        bpy.ops.mesh.primitive_cube_add(size=1, location=(0, 0, 0))
        cube = context.active_object
        cube.scale[0] = 1.0
        cube.scale[1] = 1.0
        cube.scale[2] = 0.5
        return {'FINISHED'}

def main_object(context, collection, obj, level, **kw):
    import random
    kw_copy = kw.copy()
    use_recenter = kw_copy.pop("use_recenter")
    use_remove_original = kw_copy.pop("use_remove_original")
    recursion = kw_copy.pop("recursion")
    recursion_source_limit = kw_copy.pop("recursion_source_limit")
    recursion_clamp = kw_copy.pop("recursion_clamp")
    recursion_chance = kw_copy.pop("recursion_chance")
    recursion_chance_select = kw_copy.pop("recursion_chance_select")
    use_island_split = kw_copy.pop("use_island_split")
    use_debug_bool = kw_copy.pop("use_debug_bool")
    use_interior_vgroup = kw_copy.pop("use_interior_vgroup")
    use_sharp_edges = kw_copy.pop("use_sharp_edges")
    use_sharp_edges_apply = kw_copy.pop("use_sharp_edges_apply")
    scene = context.scene
    if level != 0:
        kw_copy["source_limit"] = recursion_source_limit
    from . import fracture_cell_setup
    obj.select_set(False)
    if kw_copy["use_debug_redraw"]:
        obj_display_type_prev = obj.display_type
        obj.display_type = 'WIRE'
    objects = fracture_cell_setup.cell_fracture_objects(context, collection, obj, **kw_copy)
    objects = fracture_cell_setup.cell_fracture_boolean(
        context, collection, obj, objects,
        use_island_split=use_island_split,
        use_interior_hide=(use_interior_vgroup or use_sharp_edges),
        use_debug_bool=use_debug_bool,
        use_debug_redraw=kw_copy["use_debug_redraw"],
        level=level,
    )
    if use_recenter:
        bpy.ops.object.origin_set(
            {"selected_editable_objects": objects},
            type='ORIGIN_GEOMETRY',
            center='MEDIAN',
        )
    if level == 0:
        for level_sub in range(1, recursion + 1):
            objects_recurse_input = [(i, o) for i, o in enumerate(objects)]
            if recursion_chance != 1.0:
                from mathutils import Vector
                if recursion_chance_select == 'RANDOM':
                    random.shuffle(objects_recurse_input)
                elif recursion_chance_select in {'SIZE_MIN', 'SIZE_MAX'}:
                    objects_recurse_input.sort(key=lambda ob_pair: (
                        Vector(ob_pair[1].bound_box[0]) -
                        Vector(ob_pair[1].bound_box[6])
                    ).length_squared)
                    if recursion_chance_select == 'SIZE_MAX':
                        objects_recurse_input.reverse()
                elif recursion_chance_select in {'CURSOR_MIN', 'CURSOR_MAX'}:
                    c = scene.cursor.location.copy()
                    objects_recurse_input.sort(key=lambda ob_pair: (ob_pair[1].location - c).length_squared)
                    if recursion_chance_select == 'CURSOR_MAX':
                        objects_recurse_input.reverse()
                objects_recurse_input[int(recursion_chance * len(objects_recurse_input)):] = []
                objects_recurse_input.sort()
            objects_recurse_input.reverse()
            objects_recursive = []
            for i, obj_cell in objects_recurse_input:
                assert(objects[i] is obj_cell)
                objects_recursive += main_object(context, collection, obj_cell, level_sub, **kw)
                if use_remove_original:
                    collection.objects.unlink(obj_cell)
                    del objects[i]
                if recursion_clamp and len(objects) + len(objects_recursive) >= recursion_clamp:
                    break
            objects.extend(objects_recursive)
            if recursion_clamp and len(objects) > recursion_clamp:
                break
    if level == 0:
        if use_interior_vgroup or use_sharp_edges:
            fracture_cell_setup.cell_fracture_interior_handle(
                objects,
                use_interior_vgroup=use_interior_vgroup,
                use_sharp_edges=use_sharp_edges,
                use_sharp_edges_apply=use_sharp_edges_apply,
            )
    if kw_copy["use_debug_redraw"]:
        obj.display_type = obj_display_type_prev
    return objects

def main(context, **kw):
    import time
    t = time.time()
    objects_context = context.selected_editable_objects
    kw_copy = kw.copy()
    mass_mode = kw_copy.pop("mass_mode")
    mass = kw_copy.pop("mass")
    collection_name = kw_copy.pop("collection_name")
    collection = context.collection
    if collection_name:
        collection_current = collection
        collection = bpy.data.collections.get(collection_name)
        if collection is None:
            collection = bpy.data.collections.new(collection_name)
            collection_current.children.link(collection)
        del collection_current
    objects = []
    for obj in objects_context:
        if obj.type == 'MESH':
            objects += main_object(context, collection, obj, 0, **kw_copy)
    bpy.ops.object.select_all(action='DESELECT')
    for obj_cell in objects:
        obj_cell.select_set(True)
    if mass_mode == 'UNIFORM':
        for obj_cell in objects:
            rb = obj_cell.rigid_body
            if rb is not None:
                rb.mass = mass
    elif mass_mode == 'VOLUME':
        from mathutils import Vector
        def _get_volume(obj_cell):
            def _getObjectBBMinMax():
                min_co = Vector((1000000.0, 1000000.0, 1000000.0))
                max_co = -min_co
                matrix = obj_cell.matrix_world.copy()
                for i in range(0, 8):
                    bb_vec = matrix @ Vector(obj_cell.bound_box[i])
                    min_co[0] = min(bb_vec[0], min_co[0])
                    min_co[1] = min(bb_vec[1], min_co[1])
                    min_co[2] = min(bb_vec[2], min_co[2])
                    max_co[0] = max(bb_vec[0], max_co[0])
                    max_co[1] = max(bb_vec[1], max_co[1])
                    max_co[2] = max(bb_vec[2], max_co[2])
                return (min_co, max_co)
            def _getObjectVolume():
                min_co, max_co = _getObjectBBMinMax()
                x = max_co[0] - min_co[0]
                y = max_co[1] - min_co[1]
                z = max_co[2] - min_co[2]
                volume = x * y * z
                return volume
            return _getObjectVolume()
        obj_volume_ls = [_get_volume(obj_cell) for obj_cell in objects]
        obj_volume_tot = sum(obj_volume_ls)
        if obj_volume_tot > 0.0:
            mass_fac = mass / obj_volume_tot
            for i, obj_cell in enumerate(objects):
                rb = obj_cell.rigid_body
                if rb is not None:
                    rb.mass = obj_volume_ls[i] * mass_fac
    else:
        assert(0)
    print("Done! %d objects in %.4f sec" % (len(objects), time.time() - t))
    join_objects_with_prefix(context, "Cube.001_cell")

def join_objects_with_prefix(context, prefix):
    objects_to_join = [obj for obj in context.selected_objects if obj.name.startswith(prefix)]
    if objects_to_join:
        for obj in objects_to_join:
            obj.select_set(True)
        context.view_layer.objects.active = objects_to_join[0]
        bpy.ops.object.join()
    else:
        print("There are no objects to combine with the prefix:", prefix)

class FractureCell(Operator):
    bl_idname = "object.add_fracture_cell_objects"
    bl_label = "Cell fracture selected mesh objects"
    bl_options = {'PRESET', 'UNDO'}

    source: EnumProperty(
        name="Source",
        items=(
            ('VERT_OWN', "Own Verts", "Use own vertices"),
            ('VERT_CHILD', "Child Verts", "Use child object vertices"),
            ('PARTICLE_OWN', "Own Particles", "All particle systems of the source object"),
            ('PARTICLE_CHILD', "Child Particles", "All particle systems of the child objects"),
            ('PENCIL', "Annotation Pencil", "Annotation Grease Pencil."),
        ),
        options={'ENUM_FLAG'},
        default={'PARTICLE_OWN'},
    )

    source_limit: IntProperty(
        name="Source Limit",
        description="Limit the number of input points, 0 for unlimited",
        min=0, max=5000,
        default=0,
    )

    source_noise: FloatProperty(
        name="Noise",
        description="Randomize point distribution",
        min=0.0, max=1.0,
        default=1,
    )

    cell_scale: FloatVectorProperty(
        name="Scale",
        description="Scale Cell Shape",
        size=3,
        min=0.0, max=1.0,
        default=(0.5, 0.5, 0.5),
    )

    recursion: IntProperty(
        name="Recursion",
        description="Break shards recursively",
        min=0, max=5000,
        default=0,
    )

    recursion_source_limit: IntProperty(
        name="Source Limit",
        description="Limit the number of input points, 0 for unlimited (applies to recursion only)",
        min=0, max=5000,
        default=80,
    )

    recursion_clamp: IntProperty(
        name="Clamp Recursion",
        description="Finish recursion when this number of objects is reached (prevents recursing for extended periods of time), zero disables",
        min=0, max=10000,
        default=250,
    )

    recursion_chance: FloatProperty(
        name="Random Factor",
        description="Likelihood of recursion",
        min=0.0, max=1.0,
        default=0.25,
    )

    recursion_chance_select: EnumProperty(
        name="Recurse Over",
        items=(
            ('RANDOM', "Random", ""),
            ('SIZE_MIN', "Small", "Recursively subdivide smaller objects"),
            ('SIZE_MAX', "Big", "Recursively subdivide bigger objects"),
            ('CURSOR_MIN', "Cursor Close", "Recursively subdivide objects closer to the cursor"),
            ('CURSOR_MAX', "Cursor Far", "Recursively subdivide objects farther from the cursor"),
        ),
        default='SIZE_MIN',
    )

    use_smooth_faces: BoolProperty(
        name="Smooth Interior",
        description="Smooth Faces of inner side",
        default=False,
    )

    use_sharp_edges: BoolProperty(
        name="Sharp Edges",
        description="Set sharp edges when disabled",
        default=True,
    )

    use_sharp_edges_apply: BoolProperty(
        name="Apply Split Edge",
        description="Split sharp hard edges",
        default=False,
    )

    use_data_match: BoolProperty(
        name="Match Data",
        description="Match original mesh materials and data layers",
        default=True,
    )

    use_island_split: BoolProperty(
        name="Split Islands",
        description="Split disconnected meshes",
        default=True,
    )

    margin: FloatProperty(
        name="Margin",
        description="Gaps for the fracture (gives more stable physics)",
        min=0.0, max=1.0,
        default=0.001,
    )

    material_index: IntProperty(
        name="Material",
        description="Material index for interior faces",
        default=0,
    )

    use_interior_vgroup: BoolProperty(
        name="Interior VGroup",
        description="Create a vertex group for interior verts",
        default=False,
    )

    mass_mode: EnumProperty(
        name="Mass Mode",
        items=(
            ('VOLUME', "Volume", "Objects get part of specified mass based on their volume"),
            ('UNIFORM', "Uniform", "All objects get the specified mass"),
        ),
        default='VOLUME',
    )

    mass: FloatProperty(
        name="Mass",
        description="Mass to give created objects",
        min=0.001, max=1000.0,
        default=1.0,
    )

    use_recenter: BoolProperty(
        name="Recenter",
        description="Recalculate the center points after splitting",
        default=True,
    )

    use_remove_original: BoolProperty(
        name="Remove Original",
        description="Removes the parents used to create the shatter",
        default=True,
    )

    collection_name: StringProperty(
        name="Collection",
        description="Create objects in a collection (use existing or create new)",
    )

    use_debug_points: BoolProperty(
        name="Debug Points",
        description="Create mesh data showing the points used for fracture",
        default=False,
    )

    use_debug_redraw: BoolProperty(
        name="Show Progress Realtime",
        description="Redraw as fracture is done",
        default=True,
    )

    use_debug_bool: BoolProperty(
        name="Debug Boolean",
        description="Skip applying the boolean modifier",
        default=False,
    )

    def execute(self, context):
        keywords = self.as_keywords()
        main(context, **keywords)
        return {'FINISHED'}

    def invoke(self, context, event):
        self.execute(context)
        return {'FINISHED'}

class OBJECT_OT_add_fracture_and_combine(bpy.types.Operator):
    bl_idname = "object.add_fracture_and_combine"
    bl_label = "Apply paving stones"
    
    def execute(self, context):
        bpy.ops.object.add_fracture_cell_objects()
        bpy.ops.object.combine_objects()
        material = create_stone_material()
        bpy.ops.object.add_modifiers()
        if context.scene.show_optimization_tab:
            optimization_value = context.scene.optimization_value
            obj = bpy.context.object
            decimate_modifier5 = obj.modifiers.new(name="Decimate5", type='DECIMATE')
            decimate_modifier5.ratio = optimization_value
            bpy.ops.object.modifier_apply(modifier=decimate_modifier5.name)
        curve = bpy.context.object
        self.apply_material(curve) 
        return {'FINISHED'}
    def apply_material(self, obj):
        material_name = "StonePaving"
        if material_name not in bpy.data.materials:
            material = bpy.data.materials.new(name=material_name)
        else:
            material = bpy.data.materials[material_name]

       
        material.use_nodes = True
        bsdf = material.node_tree.nodes.get("Principled BSDF")
        if bsdf:
         
            bsdf.inputs['Base Color'].default_value = (0.5, 0.5, 0.5, 1)  

   
        if obj.data.materials:
            obj.data.materials[0] = material
        else:
            obj.data.materials.append(material)    
    


    

bpy.types.Scene.optimization_value = FloatProperty(name="Optimization", default=1, min=0.0, max=1.0)

class VIEW3D_PT_tools_panel(Panel):
    bl_label = "Generation"
    bl_idname = "VIEW3D_PT_tools_panel"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "Generation"

    def draw(self, context):
        layout = self.layout
        scene = context.scene
        
        # Сворачиваемая вкладка для генерации
        layout.prop(scene, "show_generate_tab", text="Tile")
        if scene.show_generate_tab:
            box = layout.box()
            # Здесь могут быть другие операторы
            box.operator("object.add_bezier_curve")
            box.operator("object.convert_to_mesh")
            box.operator("object.apply_material")

        # Сворачиваемая вкладка для заготовки
        layout.prop(scene, "show_template_tab", text="Blank")
        if scene.show_template_tab:
            box = layout.box()
            box.operator(CreateCubeOperator.bl_idname, text="Create a blank")
            layout.prop(scene, "cube_size_x", text="Size by X")
            layout.prop(scene, "cube_size_y", text="Size by Y")
            layout.prop(scene, "cube_size_z", text="Size by Z")
            layout.prop(scene, "subdivision_count", text="Details")

        # Сворачиваемая вкладка для брусчатки
        layout.prop(scene, "show_fracture_tab", text="Paving stones")
        if scene.show_fracture_tab:
            box = layout.box()
            box.operator("object.add_fracture_and_combine")
            layout.prop(scene, "midlevel", text="Density of stones")

            # Новая вкладка "Оптимизация"
            layout.prop(scene, "show_optimization_tab", text="Optimization")
            if scene.show_optimization_tab:
                optimization_box = layout.box()
                optimization_box.prop(scene, "optimization_value", text="Optimization")

# В register() добавьте это свойство
bpy.types.Scene.show_optimization_tab = BoolProperty(name="Show the optimization tab", default=False)

class CreateCubeOperator(Operator):
    bl_idname = "mesh.create_cube"
    bl_label = "Create Cube"

    def execute(self, context):
        scene = context.scene
        bpy.ops.mesh.primitive_cube_add(size=1.0, enter_editmode=False, align='WORLD')
        cube = context.object
        cube.scale[0] = scene.cube_size_x
        cube.scale[1] = scene.cube_size_y
        cube.scale[2] = scene.cube_size_z
        bpy.ops.object.mode_set(mode='EDIT')
        bpy.ops.mesh.subdivide(number_cuts=scene.subdivision_count)
        bpy.ops.object.mode_set(mode='OBJECT')
        return {'FINISHED'}

def register():
    bpy.utils.register_class(VIEW3D_PT_tools_panel)
    # Регистрация остальных классов
    bpy.utils.register_class(OBJECT_OT_add_fracture_and_combine)
    bpy.utils.register_class(OBJECT_OT_add_bezier_curve)
    bpy.utils.register_class(OBJECT_OT_convert_to_mesh)
    bpy.utils.register_class(OBJECT_OT_apply_material)    
    bpy.utils.register_class(CreateCubeOperator)
    bpy.utils.register_class(OBJECT_OT_combine_objects)
    bpy.utils.register_class(OBJECT_OT_add_modifiers)
    bpy.utils.register_class(FractureCell)

    # Добавление свойств в сцену для управления вкладками
    bpy.types.Scene.show_optimization_tab = BoolProperty(name="Show the optimization tab", default=False)
    bpy.types.Scene.show_generate_tab = BoolProperty(name="Show the generation tab", default=False)
    bpy.types.Scene.show_template_tab = BoolProperty(name="Show the blanks tab", default=False)
    bpy.types.Scene.show_fracture_tab = BoolProperty(name="Show the paving stones tab", default=False)

    # Добавление остальных свойств в сцену
    bpy.types.Scene.cube_size_x = bpy.props.FloatProperty(name="Size by X", default=1.0, min=0.1)
    bpy.types.Scene.cube_size_y = bpy.props.FloatProperty(name="Size by Y", default=1.0, min=0.1)
    bpy.types.Scene.cube_size_z = bpy.props.FloatProperty(name="Size by Z", default=1.0, min=0.1)
    bpy.types.Scene.midlevel = bpy.props.FloatProperty(name="Density", default=0.3, min=0.001)
    bpy.types.Scene.subdivision_count = bpy.props.IntProperty(name="Details", default=0, min=0)

def unregister():
    bpy.utils.unregister_class(VIEW3D_PT_tools_panel)
    # Отмена регистрации остальных классов
    bpy.utils.unregister_class(OBJECT_OT_add_bezier_curve)
    bpy.utils.unregister_class(OBJECT_OT_convert_to_mesh)
    bpy.utils.unregister_class(OBJECT_OT_apply_material)    
    bpy.utils.unregister_class(OBJECT_OT_add_modifiers)
    bpy.utils.unregister_class(OBJECT_OT_combine_objects)
    bpy.utils.unregister_class(OBJECT_OT_add_fracture_and_combine)
    bpy.utils.unregister_class(CreateCubeOperator)

    # Удаление свойств из сцены
    del bpy.types.Scene.show_optimization_tab
    del bpy.types.Scene.show_generate_tab
    del bpy.types.Scene.show_template_tab
    del bpy.types.Scene.show_fracture_tab
    del bpy.types.Scene.cube_size_x
    del bpy.types.Scene.cube_size_y
    del bpy.types.Scene.cube_size_z
    del bpy.types.Scene.midlevel
    del bpy.types.Scene.subdivision_count    

if __name__ == "__main__":
    register()
